import { createRouter, createWebHistory } from "vue-router";
import NProgress from "nprogress"; //进度条
import "nprogress/nprogress.css";

NProgress.configure({
  showSpinner: false, //通过将其设置为 false 来关闭加载微调器。
});

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      redirect: "/home/index",
      hidden: true,
    },
    {
      path: "/login",
      name: "login",
      meta: { title: "登陆" },
      component: () => import("@/views/admin/login.vue"),
      hidden: true,
    },
    {
      path: "/register",
      name: "register",
      meta: { title: "登陆" },
      component: () => import("@/views/admin/register.vue"),
      hidden: true,
    },
    {
      path: "/media",
      name: "media",
      meta: { title: "媒体" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "list",
          name: "media-list",
          meta: { title: "媒体资源列表" },
          component: () => import("@/views/admin/media-list.vue"),
        },
      ],
    },
    {
      path: "/user",
      name: "user",
      meta: { title: "用户" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "list",
          name: "user-list",
          meta: { title: "用户列表" },
          component: () => import("@/views/admin/user-list.vue"),
        },
      ],
    },
    // 卖家管理
    {
      path: "/cs",
      name: "cs",
      meta: { title: "卖家管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "csgl",
          name: "csgl",
          meta: { title: "卖家管理" },
          component: () => import("@/views/admin/csgl.vue"),
        },
      ],
    },

    // 买家管理
    {
      path: "/gm",
      name: "gm",
      meta: { title: "买家管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "gmgl",
          name: "gmgl",
          meta: { title: "买家管理" },
          component: () => import("@/views/admin/gmgl.vue"),
        },
      ],
    },

    // 分类管理
    {
      path: "/fl",
      name: "fl",
      meta: { title: "分类管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "flgl",
          name: "flgl",
          meta: { title: "分类管理" },
          component: () => import("@/views/admin/flgl.vue"),
        },
      ],
    },

    // 地区管理
    {
      path: "/dq",
      name: "dq",
      meta: { title: "地区管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "dqgl",
          name: "dqgl",
          meta: { title: "地区管理" },
          component: () => import("@/views/admin/dqgl.vue"),
        },
      ],
    },

    // 商品管理
    {
      path: "/sp",
      name: "sp",
      meta: { title: "商品管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "spgl",
          name: "spgl",
          meta: { title: "商品管理" },
          component: () => import("@/views/admin/spgl.vue"),
        },
      ],
    },

    // 地址管理
    {
      path: "/htdz",
      name: "htdz",
      meta: { title: "地址管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "dzgl",
          name: "dzgl",
          meta: { title: "地址管理" },
          component: () => import("@/views/admin/dzgl.vue"),
        },
      ],
    },

    // 订单管理
    {
      path: "/dd",
      name: "dd",
      meta: { title: "开课管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "ddgl",
          name: "ddgl",
          meta: { title: "开课列表" },
          component: () => import("@/views/admin/ddgl.vue"),
        },
      ],
    },


    {
      path: "/xk",
      name: "xk",
      meta: { title: "选课管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "dsp",
          name: "dsp",
          meta: { title: "待审批列表" },
          component: () => import("@/views/admin/dsp.vue"),
        },
        {
          path: "ysp",
          name: "ysp",
          meta: { title: "已审批列表" },
          component: () => import("@/views/admin/ysp.vue"),
        },
      ],
    },

    // 成绩管理
    {
      path: "/xkdf",
      name: "xkdf",
      meta: { title: "成绩管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "ddf",
          name: "ddf",
          meta: { title: "待打分列表" },
          component: () => import("@/views/admin/ddf.vue"),
        },
        {
          path: "ydf",
          name: "ydf",
          meta: { title: "已打分列表" },
          component: () => import("@/views/admin/ydf.vue"),
        },
      ],
    },

    // 通知管理
    {
      path: "/tz",
      name: "tz",
      meta: { title: "通知管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "tzgl",
          name: "tzgl",
          meta: { title: "通知列表" },
          component: () => import("@/views/admin/tzgl.vue"),
        },
      ],
    },

    // 收藏管理
    {
      path: "/htsc",
      name: "htsc",
      meta: { title: "收藏管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "scgl",
          name: "scgl",
          meta: { title: "收藏列表" },
          component: () => import("@/views/admin/scgl.vue"),
        },
      ],
    },

    // 评论管理
    {
      path: "/htpl",
      name: "htpl",
      meta: { title: "评论管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "plgl",
          name: "plgl",
          meta: { title: "评论列表" },
          component: () => import("@/views/admin/plgl.vue"),
        },
      ],
    },

    // 轮播管理
    {
      path: "/lb",
      name: "lb",
      meta: { title: "轮播管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "lbgl",
          name: "lbgl",
          meta: { title: "评论列表" },
          component: () => import("@/views/admin/lbgl.vue"),
        },
      ],
    },

    // {
    //   path: "/review",
    //   name: "review",
    //   meta: { title: "审批管理" },
    //   component: () => import("@/views/main/main.vue"),
    //   children: [
    //     {
    //       path: "list1",
    //       name: "review-list1",
    //       meta: { title: "待审批列表" },
    //       component: () => import("@/views/review/review-list1.vue"),
    //     },
    //     {
    //       path: "list",
    //       name: "review-list",
    //       meta: { title: "全部审批列表" },
    //       component: () => import("@/views/review/review-list.vue"),
    //     },
    //   ],
    // },

    // {
    //   path: "/apply",
    //   name: "apply",
    //   meta: { title: "审批管理" },
    //   component: () => import("@/views/main/main.vue"),
    //   children: [
    //     {
    //       path: "list",
    //       name: "apply-list",
    //       meta: { title: "未通过审批列表" },
    //       component: () => import("@/views/apply/apply-list.vue"),
    //     },
    //     {
    //       path: "list1",
    //       name: "apply-list1",
    //       meta: { title: "同意审批列表" },
    //       component: () => import("@/views/apply/apply-list1.vue"),
    //     },
    //     {
    //       path: "list2",
    //       name: "apply-list2",
    //       meta: { title: "待审批列表" },
    //       component: () => import("@/views/apply/apply-list2.vue"),
    //     },
    //   ],
    // },

    // 用户前台
    {
      path: '/home',
      name: 'mainqiantai',
      component: () => import('@/views/Mainqiantai.vue'),
      children: [
        {
          path: 'index',
          name: 'index',
          component: () => import("@/views/Index.vue"),
        },
        {
          path: 'detail',
          name: 'detail',
          component: () => import("@/views/Detail.vue"),
        },
        {
          path: 'confirm',
          name: 'confirm',
          component: () => import("@/views/Confirm.vue"),
        },
        {
          path: 'pay',
          name: 'pay',
          component: () => import("@/views/Pay.vue"),
        },
        {
          path: 'usercenter',
          name: 'usercenter',
          redirect: '/home/usercenter/order',
          component: () => import("@/views/User.vue"),
          children: [
            {
              path: 'order',
              name: 'order',
              component: () => import("@/views/Order.vue"),
            },
            {
              path: 'sc',
              name: 'sc',
              component: () => import("@/views/Mysc.vue"),
            },
            {
              path: 'pl',
              name: 'pl',
              component: () => import("@/views/Mypl.vue"),
            },
            {
              path: 'dz',
              name: 'dz',
              component: () => import("@/views/Mydz.vue"),
            },
            {
              path: 'zl',
              name: 'zl',
              component: () => import("@/views/Myzl.vue"),
            },
          ]
        },
        
      ]
    },
  ],
});

import defaultSettings from "@/settings";

//路由全局前置钩子
router.beforeEach((to, from, next) => {
  NProgress.start();
  document.title = `${to.meta.title || "B站程序员科科"} - ${defaultSettings.title}`;
  let token = localStorage.getItem("token");
  if (token) {
    next();
  } else {
    next();
  }
});

// //路由全局后置钩子
router.afterEach(() => {
  NProgress.done();
});

export default router;
