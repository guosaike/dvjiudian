export default{
  title: "媒体资源管理系统"
}