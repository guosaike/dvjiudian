from django.apps import AppConfig


class DvjiudianConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dvjiudian'
